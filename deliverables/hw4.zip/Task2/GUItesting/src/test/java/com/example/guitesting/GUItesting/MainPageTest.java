package com.example.guitesting.GUItesting;

import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Selenide.*;
import static org.junit.jupiter.api.Assertions.*;

import static com.codeborne.selenide.Selectors.*;

public class MainPageTest {

    private static final String BASE_URL = "https://the-internet.herokuapp.com/";
    private ChromeDriver driver;

    @BeforeEach
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
        driver = new ChromeDriver();
    }

    @AfterEach
    public void end() {
        driver.quit();
    }

    /**
     * Test Scenario 1
     */
    @Test
    public void testUploadWithNoFileFails() {
        // open endpoint
        setUp("upload");

        // configure selenide elements
        SelenideElement uploadButton = $(byId("file-submit"));

        // perform actions
        uploadButton.click();

        // assert behavior
        SelenideElement heading = $(byXpath("/html/body/h1"));
        assertEquals("Internal Server Error", heading.getText());
    }

    /**
     * Test Scenario 2
     */
    @Test
    public void testHoversShowsUserOne() {
        // open endpoint
        setUp("hovers");

        // configure selenide elements
        SelenideElement figure = $(elements(byClassName("figure")).get(0));
        SelenideElement caption = $(elements(byClassName("figcaption")).get(0).$("h5"));

        // perform actions
        figure.hover();

        // assert behavior
        assertTrue(caption.isDisplayed());
    }

    /**
     * Test Scenario 3
     */
    @Test
    public void testCheckboxesBoxOneUncheckedBoxTwoSelected() {
        // open endpoint
        setUp("checkboxes");

        // configure selenide elements
        SelenideElement boxOne = $(byCssSelector("#checkboxes > input[type=checkbox]:nth-child(1)"));
        SelenideElement boxTwo = $(byCssSelector("#checkboxes > input[type=checkbox]:nth-child(3)"));

        // assert behavior
        assertFalse(boxOne.isSelected());
        assertTrue(boxTwo.isSelected());
    }

    /**
     * Test Scenario 4
     */
    @Test
    public void testContextMenuRightClickShowsMessageBox() {
        // open endpoint
        setUp("context_menu");

        // configure selenide elements
        SelenideElement box = $(byId("hot-spot"));

        // perform actions
        String str = box.contextClick().toString();

        // assert behavior
        assertTrue(str.contains("UnhandledAlertException"));
    }

    /**
     * Test Scenario 5
     */
    @Test
    public void testBrokenImages() {
        // open endpoint
        setUp("broken_images");

        // configure selenide elements
        SelenideElement img1 = $(By.cssSelector("#content > div > img:nth-child(2)"));
        SelenideElement img2 = $(By.cssSelector("#content > div > img:nth-child(3)"));
        SelenideElement img3 = $(By.cssSelector("#content > div > img:nth-child(4)"));

        // assert behavior
        assertEquals("0", img1.getAttribute("naturalWidth"));
        assertEquals("0", img2.getAttribute("naturalWidth"));
        assertNotEquals("0", img3.getAttribute("naturalWidth"));
    }

    /**
     * Test Scenario 6
     */
    @Test
    public void testInfiniteScroll195() {
        // open endpoint
        driver.get(BASE_URL + "infinite_scroll");

        // perform actions
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 195);");

        // assert behavior
        System.out.println("");
    }

    /**
     * Test Scenario 7
     */
    @Test
    public void testDropdownSelectOptionTwo() {
        // open endpoint
        driver.get(BASE_URL + "dropdown");

        // configure selenide elements
        Select dropdown = new Select(driver.findElement(byId("dropdown")));

        // perform actions
        dropdown.selectByIndex(2);System.out.println("hello");
    }

    /**
     * Test Scenario 8
     */
    @Test
    public void testKeyPressesDownKey() {
        // open endpoint
        setUp("key_presses");

        // configure selenide elements
        SelenideElement textBox = $(byId("target"));
        SelenideElement result = $(byId("result"));

        // perform actions
        textBox.sendKeys(Keys.DOWN);

        // assert behavior
        assertEquals("You entered: DOWN", result.getText());
    }

    /**
     * Test Scenario 9
     */
    @Test
    public void testLoginEmptyUsernameAndPassword() {
        // open endpoint
        setUp("login");

        // configure selenide elements
        SelenideElement login = $(byCssSelector("#login > button > i"));
        SelenideElement flash = $(byId("flash"));

        // perform actions
        login.click();

        // assert behavior
        assertTrue(flash.getText().contains("Your username is invalid!"));
    }

    /**
     * Test Scenario 10
     */
    @Test
    public void testLoginEmptyPassword() {
        // open endpoint
        setUp("login");

        // configure selenide elements
        SelenideElement username = $(byId("username"));
        SelenideElement password = $(byId("password"));
        SelenideElement login = $(byCssSelector("#login > button > i"));
        SelenideElement flash = $(byId("flash"));

        // perform actions
        username.sendKeys("tomsmith");
        login.click();

        // assert behavior
        assertTrue(flash.getText().contains("Your password is invalid!"));
    }

    /**
     * Test Scenario 11
     */
    @Test
    public void testLoginSuccessfulLogin() {
        // open endpoint
        setUp("login");

        // configure selenide elements
        SelenideElement username = $(byId("username"));
        SelenideElement password = $(byId("password"));
        SelenideElement login = $(byCssSelector("#login > button > i"));
        SelenideElement flash = $(byId("flash"));
        SelenideElement logout = $(byCssSelector("#content > div > a"));

        // perform actions
        username.sendKeys("tomsmith");
        password.sendKeys("SuperSecretPassword!");
        login.click();

        // assert behavior
        assertTrue(WebDriverRunner.url().endsWith("secure"));
        assertTrue(flash.getText().contains("You logged into a secure area!"));
        assertTrue(logout.isEnabled());
        assertTrue(logout.isDisplayed());

        // perform actions
        logout.click();

        // assert behavior
        assertTrue(WebDriverRunner.url().endsWith("login"));
        assertTrue(flash.getText().contains("You logged out of the secure area!"));
    }

    /**
     * Opens the "the-internet" webpage in the specified endpoint.
     */
    private void setUp(String endpoint) {
        String url = String.format("%s%s", BASE_URL, endpoint);
        open(url);
    }
}
